package com.diu.bloodbank;

/**
 * Created by user on 11/26/2017.
 */

public class Donors {

    public String date;

    public Donors() {
    }

    public Donors(String date) {
        this.date = date;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
